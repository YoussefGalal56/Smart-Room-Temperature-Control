#include <Wire.h> 
#include <LiquidCrystal_I2C.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);

bool lcdPower = true;


void setupLCD() {
  lcd.init();
  lcd.clear();
  lcd.backlight();
  lcd.setCursor(0,0);
  lcd.print("System Ready");
  delay(1000);
}

void updateLCD(float temp, float hum, int fanMode, bool isAuto) {

  if (!lcdPower) return;

  lcd.clear();
  lcd.setCursor(0,0);
  lcd.print("T:");
  lcd.print(temp, 1);
  lcd.print("C ");

  lcd.print("H:");
  lcd.print(hum);
  lcd.print("%");

  lcd.setCursor(0,1);
  lcd.print ("Fan Speed:");
  if (fanMode == 0) {
    lcd.print("OFF");
  } else if (fanMode == 1)  {
    lcd.print ("LOW");
  } else if (fanMode == 2)  {
    lcd.print ("MED");
  } else if (fanMode == 3)  {
    lcd.print ("HIGH");
  }
  if (isAuto) {
    lcd.print (" AU");
  } else if (!isAuto) {
    lcd.print (" MA");
  }
}