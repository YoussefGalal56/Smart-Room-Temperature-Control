#include "hardware.h"

void setupMotor () {
  pinMode (IN3, OUTPUT);
  pinMode (IN4, OUTPUT);
  pinMode (ENB, OUTPUT);
}

void fanDirection () {
  digitalWrite (IN3, HIGH);
  digitalWrite (IN4, LOW);
}

void applyFanMode () {
  fanDirection ();
  if (fanMode == 0) {
    analogWrite(ENB, 0);
  } else if (fanMode == 1) {
    analogWrite(ENB, 150);
  } else if (fanMode == 2) {
    analogWrite(ENB, 190);
  } else if (fanMode == 3) {
    analogWrite(ENB, 255);
  }
}

void autoControl (float temp) {
  if (temp <= tempThreshold1) {
    fanMode = 0;
  }
  else if (temp > tempThreshold1 && temp <= tempThreshold2) {
    fanMode = 1;
  }
  else if (temp > tempThreshold2 && temp <= tempThreshold3) {
    fanMode = 2;
  }
  else if (temp > tempThreshold3) {
    fanMode = 3;
  }
  applyFanMode ();
}

void manualControl () {
  fanMode = fanSpeedBtns (fanMode);
  applyFanMode ();
}