#pragma once

void setupBtns ();
int fanSpeedBtns (int currentMode);
bool toggleAuto (bool currentState);

void setupLCD ();
void updateLCD (float temp, float hum, int fanMode, bool isAuto);

void setupDHT ();
float readTemperature ();
float readHumidity ();

void setupMotor ();
void fanDirection ();
void applyFanMode ();
void autoControl (float temp);
void manualControl ();
