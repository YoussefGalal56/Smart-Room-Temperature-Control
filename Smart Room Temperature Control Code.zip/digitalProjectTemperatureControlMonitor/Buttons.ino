#include "hardware.h"

void setupBtns (){
  pinMode (BTN_OFF , INPUT_PULLUP);
  pinMode (BTN_LOW , INPUT_PULLUP);
  pinMode (BTN_MED , INPUT_PULLUP);
  pinMode (BTN_HIGH , INPUT_PULLUP);
  pinMode (BTN_AUTO , INPUT_PULLUP);
}


int fanSpeedBtns (int currentMode) {
  if (digitalRead(BTN_OFF) == LOW) {
    return 0;
  }
  if (digitalRead(BTN_LOW) == LOW) {
    return 1;
  }
  if (digitalRead(BTN_MED) == LOW) {
    return 2;
  }
  if (digitalRead(BTN_HIGH) == LOW) {
    return 3;
  } 
  return currentMode;
}

bool toggleAuto (bool currentState) {
  static bool lastState = HIGH;
  bool state = digitalRead (BTN_AUTO);
  if(state == LOW && lastState == HIGH) {
    currentState = !currentState;
  }
  lastState = state;
  return currentState;
}