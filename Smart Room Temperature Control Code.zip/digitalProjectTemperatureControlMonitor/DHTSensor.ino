#include "hardware.h"
#include <DHT.h>


DHT dht(DHT_PIN, DHTTYPE);

void setupDHT(){
  dht.begin();
}

float readTemperature(){
  float temp = dht.readTemperature();
  
  if (isnan(temp)) {
    return -1;
  }
  
  return temp;
}
float readHumidity() {
  float hum = dht.readHumidity();
  
  if (isnan(hum)) {
    return -1;
  }
  return hum;
}