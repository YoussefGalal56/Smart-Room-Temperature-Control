#pragma once

#define BTN_OFF 3
#define BTN_LOW 4
#define BTN_MED 5
#define BTN_HIGH 6
#define BTN_AUTO 2
#define DHT_PIN 8
#define DHTTYPE DHT22
#define IN3 11
#define IN4 12
#define ENB 9
#define tempThreshold1 25
#define tempThreshold2 30
#define tempThreshold3 35

extern int fanMode;