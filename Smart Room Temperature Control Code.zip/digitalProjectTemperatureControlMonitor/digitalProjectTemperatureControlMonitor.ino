#include "hardware.h"
#include "functions.h"

int fanMode = 0;
bool isAuto = true;

void setup() {
  setupBtns ();
  setupDHT ();
  setupLCD ();
  setupMotor ();
  fanDirection ();
}

void loop() {
  float temp = readTemperature ();
  float hum = readHumidity ();
  isAuto = toggleAuto(isAuto);

  if (isAuto) {
   autoControl (temp);
  } else if (!isAuto) {
    manualControl ();
  }

  updateLCD(temp, hum, fanMode, isAuto);
  delay (1000);
  }
